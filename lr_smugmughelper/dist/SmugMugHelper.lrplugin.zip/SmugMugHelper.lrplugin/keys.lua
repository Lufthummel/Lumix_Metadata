--
-- Created by IntelliJ IDEA.
-- User: hkremmin
-- Date: 18.05.18
-- Time: 08:10
-- To change this template use File | Settings | File Templates.
--

-- OAuth constants
_G.SMUGMUGCONSUMERKEY = "add here"
_G.SMUGMUGSECRETKEY = "add here"

