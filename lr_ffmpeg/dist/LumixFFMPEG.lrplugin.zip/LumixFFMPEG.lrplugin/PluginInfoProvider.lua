--
-- Created by IntelliJ IDEA.
-- User: hkremmin
-- Date: 15.04.16
-- Time: 18:34
-- To change this template use File | Settings | File Templates.
--

require 'PluginManager'

return {
    sectionsForTopOfDialog = PluginManager.sectionsForTopOfDialog,
    sectionsForBottomOfDialog = PluginManager.sectionsForBottomOfDialog,
    endDialog = PluginManager.endDialog
}